﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace frigiderInteligent
{
    public class persoana
    {
        public string idpersoana
        {
            get;
            set;
        }
        public string nume
        {
            get;
            set;
        }
        public string prenume
        {
            get;
            set;
        }
        public string telefon
        {
            get;
            set;
        }
         public persoana()
        { 
            
        }
    }
}
